package com.example.EmployeeApplicationProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeApplicationProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeApplicationProjectApplication.class,args);
        System.out.println("Program Started");
    }
}